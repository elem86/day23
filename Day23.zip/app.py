import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"

st.set_page_config(page_title="CSV Data Profiler", layout="wide")

st.title("📊 CSV Data Profiler")

uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.subheader("📁 Dataset Preview")
    st.dataframe(df.head())

    st.subheader("🧮 Basic Info")
    st.write(f"**Shape:** {df.shape[0]} rows × {df.shape[1]} columns")
    st.write("**Column Types:**")
    st.dataframe(df.dtypes.astype(str))

    st.subheader("🔍 Missing Values")
    missing = df.isnull().sum()
    st.dataframe(missing[missing > 0])

    # Plot missing values
    if missing.sum() > 0:
        fig, ax = plt.subplots()
        missing[missing > 0].sort_values().plot(kind="barh", ax=ax, color="tomato")
        ax.set_title("Missing Values per Column")
        st.pyplot(fig)

    st.subheader("🧬 Unique Values per Column")
    st.dataframe(df.nunique().sort_values(ascending=False))

    st.subheader("📌 Top 3 Most Frequent Values per Column")
    for col in df.columns:
        st.markdown(f"**{col}**")
        st.dataframe(df[col].value_counts(dropna=False).head(3))

    # Numeric histogram
    num_cols = df.select_dtypes(include="number").columns
    if len(num_cols) > 0:
        num_col = st.selectbox("Choose a numeric column for histogram:", num_cols)
        fig, ax = plt.subplots()
        sns.histplot(df[num_col].dropna(), kde=True, ax=ax, color="skyblue")
        ax.set_title(f"Distribution of {num_col}")
        st.pyplot(fig)
else:
    st.info("Please upload a CSV file to begin.")
